/* Dados de exemplo usados enquanto não há back-end.
   Estrutura igual à das entidades Java (Question, Alternative, Exam, Subject). */
window.Dignitas = window.Dignitas || {};

Dignitas.dados = {
    disciplinas: ['Língua Portuguesa', 'Matemática', 'Geografia', 'Direito Constitucional', 'Informática'],
    bancas: ['Dignitas', 'Cebraspe', 'FGV', 'Vunesp'],

    questoes: [
        {
            id: 1, numero: 1, disciplina: 'Língua Portuguesa', banca: 'Dignitas', ano: 2024, concurso: 'Simulado 1',
            textoBase: 'Nas últimas décadas, o avanço das tecnologias digitais transformou as formas de interação social.',
            enunciado: 'No contexto apresentado, a principal consequência do avanço tecnológico nas relações humanas é:',
            alternativas: [
                { letra: 'A', texto: 'A substituição completa das relações presenciais por interações digitais.', correta: false },
                { letra: 'B', texto: 'A eliminação das barreiras culturais entre diferentes sociedades.', correta: false },
                { letra: 'C', texto: 'A transformação das formas de interação social mediadas pela tecnologia.', correta: true },
                { letra: 'D', texto: 'O isolamento total dos indivíduos em ambientes virtuais.', correta: false },
                { letra: 'E', texto: 'A redução do uso de ferramentas digitais na comunicação cotidiana.', correta: false }
            ],
            anulada: false, atualizadaEm: '2026-10-01'
        },
        {
            id: 2, numero: 2, disciplina: 'Matemática', banca: 'Vunesp', ano: 2023, concurso: 'Prefeitura',
            enunciado: 'Um produto custava R$ 80,00 e teve aumento de 15%. Qual é o novo preço?',
            alternativas: [
                { letra: 'A', texto: 'R$ 88,00', correta: false },
                { letra: 'B', texto: 'R$ 92,00', correta: true },
                { letra: 'C', texto: 'R$ 95,00', correta: false },
                { letra: 'D', texto: 'R$ 96,00', correta: false },
                { letra: 'E', texto: 'R$ 100,00', correta: false }
            ],
            anulada: false, atualizadaEm: '2026-09-28'
        },
        {
            id: 3, numero: 7, disciplina: 'Geografia', banca: 'FGV', ano: 2022, concurso: 'IBGE',
            enunciado: 'Qual bioma brasileiro ocupa a maior extensão territorial?',
            alternativas: [
                { letra: 'A', texto: 'Cerrado', correta: false },
                { letra: 'B', texto: 'Mata Atlântica', correta: false },
                { letra: 'C', texto: 'Amazônia', correta: true },
                { letra: 'D', texto: 'Caatinga', correta: false },
                { letra: 'E', texto: 'Pampa', correta: false }
            ],
            anulada: false, atualizadaEm: '2026-09-20'
        },
        {
            id: 4, numero: 12, disciplina: 'Direito Constitucional', banca: 'Cebraspe', ano: 2024, concurso: 'TRF 1',
            enunciado: 'A casa é asilo inviolável do indivíduo, ninguém nela podendo penetrar sem consentimento do morador, salvo nos casos previstos na Constituição.',
            alternativas: [
                { letra: 'C', texto: 'Certo', correta: true },
                { letra: 'E', texto: 'Errado', correta: false }
            ],
            anulada: false, atualizadaEm: '2026-10-05'
        },
        {
            id: 5, numero: 21, disciplina: 'Informática', banca: 'FGV', ano: 2023, concurso: 'TJ',
            enunciado: 'No Windows, qual atalho de teclado abre o Gerenciador de Tarefas diretamente?',
            alternativas: [
                { letra: 'A', texto: 'Ctrl + Alt + Del', correta: false },
                { letra: 'B', texto: 'Ctrl + Shift + Esc', correta: true },
                { letra: 'C', texto: 'Alt + F4', correta: false },
                { letra: 'D', texto: 'Windows + E', correta: false },
                { letra: 'E', texto: 'Ctrl + Esc', correta: false }
            ],
            anulada: false, atualizadaEm: '2026-09-15'
        },
        {
            id: 6, numero: 15, disciplina: 'Matemática', banca: 'Cebraspe', ano: 2022, concurso: 'PF',
            enunciado: 'Questão anulada pela banca por erro no enunciado.',
            alternativas: [
                { letra: 'A', texto: '10', correta: false },
                { letra: 'B', texto: '12', correta: false },
                { letra: 'C', texto: '14', correta: false },
                { letra: 'D', texto: '16', correta: false },
                { letra: 'E', texto: '18', correta: false }
            ],
            anulada: true, atualizadaEm: '2026-08-30'
        }
    ]
};
