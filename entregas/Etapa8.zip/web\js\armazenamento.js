/* Repositório no navegador: guarda no localStorage o que o usuário faz nas páginas
   (questões cadastradas, respostas, marcações). Substitui o back-end nesta etapa.
   Se o armazenamento estiver indisponível (janela anônima, bloqueio), as páginas
   continuam funcionando só com os dados de exemplo. */
window.Dignitas = window.Dignitas || {};

Dignitas.repo = (function () {
    const CHAVES = {
        questoes: 'dignitas.questoes',
        tentativas: 'dignitas.tentativas',
        marcadas: 'dignitas.marcadas',
        importacoes: 'dignitas.importacoes'
    };

    function ler(chave, padrao) {
        try {
            const bruto = localStorage.getItem(chave);
            return bruto ? JSON.parse(bruto) : padrao;
        } catch (e) {
            return padrao;
        }
    }

    function gravar(chave, valor) {
        try {
            localStorage.setItem(chave, JSON.stringify(valor));
            return true;
        } catch (e) {
            return false;
        }
    }

    function questoes() {
        return Dignitas.dados.questoes.concat(ler(CHAVES.questoes, []));
    }

    function questao(id) {
        return questoes().find(function (q) { return q.id === id; }) || null;
    }

    /** Já existe questão com o mesmo conteúdo normalizado? */
    function duplicada(q) {
        const chave = Dignitas.regras.chaveConteudo(q);
        return questoes().some(function (x) {
            return x.id !== q.id && Dignitas.regras.chaveConteudo(x) === chave;
        });
    }

    function adicionarQuestao(q) {
        const salvas = ler(CHAVES.questoes, []);
        const maiorId = questoes().reduce(function (m, x) { return Math.max(m, x.id); }, 0);
        q.id = maiorId + 1;
        q.atualizadaEm = new Date().toISOString().slice(0, 10);
        salvas.push(q);
        return gravar(CHAVES.questoes, salvas) ? q : null;
    }

    function tentativas() {
        return ler(CHAVES.tentativas, []);
    }

    function registrarTentativa(questaoId, letra, correta) {
        const lista = tentativas();
        lista.push({ id: lista.length + 1, questaoId: questaoId, letra: letra, correta: correta, em: new Date().toISOString() });
        gravar(CHAVES.tentativas, lista);
    }

    function limparTentativas() {
        try { localStorage.removeItem(CHAVES.tentativas); } catch (e) { /* ignora */ }
    }

    function marcadas() {
        return ler(CHAVES.marcadas, []);
    }

    function alternarMarcada(id) {
        const lista = marcadas();
        const i = lista.indexOf(id);
        if (i >= 0) lista.splice(i, 1); else lista.push(id);
        gravar(CHAVES.marcadas, lista);
        return i < 0;
    }

    function importacoes() {
        return ler(CHAVES.importacoes, []);
    }

    function registrarImportacao(registro) {
        const lista = importacoes();
        lista.unshift(registro);
        gravar(CHAVES.importacoes, lista);
    }

    function limparTudo() {
        Object.keys(CHAVES).forEach(function (k) {
            try { localStorage.removeItem(CHAVES[k]); } catch (e) { /* ignora */ }
        });
    }

    return {
        questoes, questao, duplicada, adicionarQuestao,
        tentativas, registrarTentativa, limparTentativas, marcadas, alternarMarcada,
        importacoes, registrarImportacao, limparTudo
    };
})();
