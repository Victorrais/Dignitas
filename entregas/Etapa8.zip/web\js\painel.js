/* Painel: números gerais, últimas respostas e acerto por disciplina. */
document.addEventListener('DOMContentLoaded', function () {
    const { repo, regras, ui } = Dignitas;
    const questoes = repo.questoes();
    const tentativas = repo.tentativas();
    const acertos = tentativas.filter(function (t) { return t.correta; }).length;
    const respondidas = new Set(tentativas.map(function (t) { return t.questaoId; })).size;

    document.getElementById('st-questoes').textContent = questoes.length;
    document.getElementById('st-respondidas').textContent = respondidas;
    document.getElementById('st-acerto').textContent = ui.percentual(regras.precisao(acertos, tentativas.length));
    document.getElementById('st-marcadas').textContent = repo.marcadas().length;

    const ultimas = document.getElementById('ultimas');
    const recentes = tentativas.slice(-5).reverse();
    if (recentes.length === 0) {
        ultimas.innerHTML = '<li class="empty">Nenhuma resposta ainda. <a href="praticar.html">Comece a praticar</a>.</li>';
    } else {
        ultimas.innerHTML = recentes.map(function (t) {
            const q = repo.questao(t.questaoId);
            const titulo = q ? q.enunciado : 'Questão removida';
            return '<li><span class="badge ' + (t.correta ? 'badge-ok">Certa' : 'badge-error">Errada') + '</span>'
                + '<a href="praticar.html?id=' + t.questaoId + '">' + ui.escapar(titulo) + '</a>'
                + '<small>' + ui.dataHora(t.em) + '</small></li>';
        }).join('');
    }

    const porDisciplina = {};
    tentativas.forEach(function (t) {
        const q = repo.questao(t.questaoId);
        const nome = q && q.disciplina ? q.disciplina : 'Sem disciplina';
        porDisciplina[nome] = porDisciplina[nome] || { total: 0, acertos: 0 };
        porDisciplina[nome].total++;
        if (t.correta) porDisciplina[nome].acertos++;
    });
    const alvo = document.getElementById('por-disciplina');
    const nomes = Object.keys(porDisciplina);
    if (nomes.length === 0) {
        alvo.innerHTML = '<p class="empty">As taxas aparecem depois das primeiras respostas.</p>';
        return;
    }
    alvo.innerHTML = nomes.map(function (nome) {
        const d = porDisciplina[nome];
        const p = regras.precisao(d.acertos, d.total);
        return '<div class="linha-barra"><div class="linha-barra-topo"><span>' + ui.escapar(nome) + '</span>'
            + '<strong>' + ui.percentual(p) + '</strong></div>'
            + '<div class="bar"><span style="width:' + Math.round(p * 100) + '%"></span></div></div>';
    }).join('');
});
