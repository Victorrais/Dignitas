/* Estatísticas: totais, gráfico dos últimos 7 dias e acerto por disciplina e por banca.
   Os agrupamentos seguem o StatsService do back-end. */
document.addEventListener('DOMContentLoaded', function () {
    const { repo, regras, ui } = Dignitas;
    const tentativas = repo.tentativas();
    const acertos = tentativas.filter(function (t) { return t.correta; }).length;

    document.getElementById('e-tentativas').textContent = tentativas.length;
    document.getElementById('e-acertos').textContent = acertos;
    document.getElementById('e-erros').textContent = tentativas.length - acertos;
    document.getElementById('e-acerto').textContent = ui.percentual(regras.precisao(acertos, tentativas.length));

    // ---------- Últimos 7 dias (dias sem resposta aparecem zerados) ----------
    const hoje = new Date();
    hoje.setHours(0, 0, 0, 0);
    const dias = [];
    for (let i = 6; i >= 0; i--) {
        const d = new Date(hoje);
        d.setDate(hoje.getDate() - i);
        dias.push({ data: d, total: 0, acertos: 0 });
    }
    tentativas.forEach(function (t) {
        const d = new Date(t.em);
        d.setHours(0, 0, 0, 0);
        const dia = dias.find(function (x) { return x.data.getTime() === d.getTime(); });
        if (!dia) return;
        dia.total++;
        if (t.correta) dia.acertos++;
    });
    const maximo = Math.max(1, ...dias.map(function (d) { return d.total; }));
    document.getElementById('dias').innerHTML = dias.map(function (d) {
        const altura = Math.round(d.total / maximo * 100);
        const pAcertos = d.total ? d.acertos / d.total * 100 : 0;
        const rotulo = d.data.toLocaleDateString('pt-BR', { weekday: 'short' }).replace('.', '');
        return '<div class="dia" title="' + d.total + ' respostas, ' + d.acertos + ' acertos">'
            + '<strong>' + d.total + '</strong>'
            + '<div class="dia-coluna" style="height:' + altura + '%">'
            + '<span class="acertos" style="height:' + pAcertos + '%"></span>'
            + '<span class="erros" style="height:' + (d.total ? 100 - pAcertos : 0) + '%"></span>'
            + '</div><small>' + rotulo + '</small></div>';
    }).join('');

    // ---------- Agrupamentos ----------
    function agrupar(chave, padrao) {
        const grupos = {};
        tentativas.forEach(function (t) {
            const q = repo.questao(t.questaoId);
            const nome = (q && q[chave]) || padrao;
            grupos[nome] = grupos[nome] || { total: 0, acertos: 0 };
            grupos[nome].total++;
            if (t.correta) grupos[nome].acertos++;
        });
        return Object.keys(grupos).map(function (nome) {
            return { nome: nome, total: grupos[nome].total, acertos: grupos[nome].acertos };
        }).sort(function (a, b) { return b.total - a.total; });
    }

    function tabela(id, linhas) {
        const corpo = document.getElementById(id);
        if (linhas.length === 0) {
            corpo.innerHTML = '<tr><td colspan="4" class="empty">Sem respostas ainda.</td></tr>';
            return;
        }
        corpo.innerHTML = linhas.map(function (l) {
            const p = regras.precisao(l.acertos, l.total);
            return '<tr><td>' + ui.escapar(l.nome) + '</td>'
                + '<td class="num">' + l.total + '</td>'
                + '<td class="num">' + ui.percentual(p) + '</td>'
                + '<td><div class="bar"><span style="width:' + Math.round(p * 100) + '%"></span></div></td></tr>';
        }).join('');
    }

    tabela('t-disciplina', agrupar('disciplina', 'Sem disciplina'));
    tabela('t-banca', agrupar('banca', 'Sem banca'));
});
