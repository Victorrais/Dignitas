/* Lista de questões: filtros em tempo real, ordenação, paginação e marcação para revisão. */
document.addEventListener('DOMContentLoaded', function () {
    const { repo, regras, ui, dados } = Dignitas;
    const TAMANHO_PAGINA = 5;
    const form = document.getElementById('form-filtros');
    const campoTexto = document.getElementById('f-texto');
    const erroTexto = document.getElementById('erro-texto');
    const corpo = document.getElementById('tabela');
    let pagina = 0;

    const select = document.getElementById('f-disciplina');
    dados.disciplinas.forEach(function (d) {
        const op = document.createElement('option');
        op.value = d;
        op.textContent = d;
        select.appendChild(op);
    });

    /** Busca com 1 ou 2 letras traria resultados demais e sem sentido: exige 3 ou mais. */
    function textoValido() {
        const t = campoTexto.value.trim();
        const ok = t.length === 0 || t.length >= 3;
        erroTexto.textContent = ok ? '' : 'Digite pelo menos 3 caracteres.';
        campoTexto.closest('.field').classList.toggle('invalid', !ok);
        campoTexto.setAttribute('aria-invalid', String(!ok));
        return ok;
    }

    function filtrar() {
        const texto = regras.normalizar(campoTexto.value);
        const disciplina = select.value;
        const status = document.getElementById('f-status').value;
        const ordem = document.getElementById('f-ordem').value;
        const tentativas = repo.tentativas();
        const marcadas = repo.marcadas();

        const lista = repo.questoes().filter(function (q) {
            if (texto.length >= 3 && regras.normalizar(q.enunciado).indexOf(texto) < 0) return false;
            if (disciplina && q.disciplina !== disciplina) return false;
            const minhas = tentativas.filter(function (t) { return t.questaoId === q.id; });
            if (status === 'nao-respondidas' && minhas.length > 0) return false;
            if (status === 'erradas' && !minhas.some(function (t) { return !t.correta; })) return false;
            if (status === 'marcadas' && marcadas.indexOf(q.id) < 0) return false;
            return true;
        });

        lista.sort(function (a, b) {
            if (ordem === 'numero') return (a.numero || 0) - (b.numero || 0);
            const dif = String(b.atualizadaEm).localeCompare(String(a.atualizadaEm));
            return ordem === 'antigas' ? -dif : dif;
        });
        return lista;
    }

    function desenhar() {
        if (!textoValido()) return;
        const lista = filtrar();
        const total = regras.paginas(lista.length, TAMANHO_PAGINA);
        if (pagina >= total) pagina = total - 1;
        const fatia = lista.slice(pagina * TAMANHO_PAGINA, (pagina + 1) * TAMANHO_PAGINA);
        const marcadas = repo.marcadas();

        document.getElementById('contagem').textContent =
            lista.length + (lista.length === 1 ? ' questão' : ' questões');
        document.getElementById('pagina-info').textContent = 'Página ' + (pagina + 1) + ' de ' + total;
        document.getElementById('anterior').disabled = pagina === 0;
        document.getElementById('proxima').disabled = pagina >= total - 1;

        if (fatia.length === 0) {
            corpo.innerHTML = '<tr><td colspan="5" class="empty">Nenhuma questão encontrada com esses filtros.</td></tr>';
            return;
        }
        corpo.innerHTML = fatia.map(function (q) {
            const marcada = marcadas.indexOf(q.id) >= 0;
            return '<tr>'
                + '<td class="num">' + (q.numero || '—') + '</td>'
                + '<td><span class="enunciado-curto">' + ui.escapar(q.enunciado) + '</span>'
                + (q.anulada ? ' <span class="badge badge-warn">Anulada</span>' : '') + '</td>'
                + '<td>' + ui.escapar(q.disciplina || '—') + '</td>'
                + '<td>' + ui.escapar(regras.rotuloConcurso(q.banca, q.ano, q.concurso)) + '</td>'
                + '<td><div class="acoes">'
                + '<a class="btn btn-small btn-primary" href="praticar.html?id=' + q.id + '">Resolver</a>'
                + '<button class="btn btn-small" type="button" data-marcar="' + q.id + '" aria-pressed="' + marcada + '">'
                + (marcada ? 'Desmarcar' : 'Marcar') + '</button>'
                + '</div></td></tr>';
        }).join('');
    }

    form.addEventListener('input', function () { pagina = 0; desenhar(); });
    form.addEventListener('submit', function (e) { e.preventDefault(); desenhar(); });
    form.addEventListener('reset', function () { setTimeout(function () { pagina = 0; desenhar(); }); });
    document.getElementById('anterior').addEventListener('click', function () { pagina--; desenhar(); });
    document.getElementById('proxima').addEventListener('click', function () { pagina++; desenhar(); });

    corpo.addEventListener('click', function (e) {
        const botao = e.target.closest('[data-marcar]');
        if (!botao) return;
        const marcou = repo.alternarMarcada(Number(botao.dataset.marcar));
        ui.aviso(marcou ? 'Questão marcada para revisão.' : 'Marcação removida.');
        desenhar();
    });

    desenhar();
});
