/* Importar PDF: valida o arquivo e os dados do concurso, simula a extração e permite revisar.
   A extração real (PDFBox + OCR) será feita pelo back-end; aqui o resultado é simulado. */
document.addEventListener('DOMContentLoaded', function () {
    const { repo, regras, ui, dados } = Dignitas;
    const TAMANHO_MAXIMO = 20 * 1024 * 1024;
    const form = document.getElementById('form-arquivo');
    const entrada = document.getElementById('arquivo');
    const zona = document.getElementById('zona');
    const caixaErros = document.getElementById('erros-arquivo');
    let arquivo = null;
    let extraidas = [];

    document.getElementById('lista-bancas').innerHTML = dados.bancas.map(function (b) {
        return '<option value="' + ui.escapar(b) + '">';
    }).join('');

    function plural(n, singular, varios) {
        return n + ' ' + (n === 1 ? singular : varios);
    }

    // ---------- Escolha do arquivo (clique ou arrastar) ----------

    function escolher(f) {
        arquivo = f || null;
        const rotulo = document.getElementById('nome-arquivo');
        rotulo.hidden = !arquivo;
        rotulo.textContent = arquivo ? arquivo.name + ' · ' + (arquivo.size / 1024 / 1024).toFixed(1) + ' MB' : '';
    }

    entrada.addEventListener('change', function () { escolher(entrada.files[0]); });
    ['dragenter', 'dragover'].forEach(function (ev) {
        zona.addEventListener(ev, function (e) { e.preventDefault(); zona.classList.add('arrastando'); });
    });
    ['dragleave', 'drop'].forEach(function (ev) {
        zona.addEventListener(ev, function (e) { e.preventDefault(); zona.classList.remove('arrastando'); });
    });
    zona.addEventListener('drop', function (e) { escolher(e.dataTransfer.files[0]); });

    // ---------- Validação ----------

    /** Mesmo nome e tamanho de um arquivo já importado: no back-end, o hash do arquivo. */
    function jaImportado(f) {
        return repo.importacoes().some(function (i) { return i.arquivo === f.name && i.tamanho === f.size; });
    }

    function marcar(id, mensagem) {
        const campo = document.getElementById(id);
        campo.closest('.field').classList.toggle('invalid', !!mensagem);
        campo.setAttribute('aria-invalid', String(!!mensagem));
        document.getElementById('erro-' + id).textContent = mensagem || '';
    }

    function validar() {
        const erros = [];
        if (!arquivo) {
            erros.push('Escolha um arquivo PDF.');
        } else {
            const ehPdf = /\.pdf$/i.test(arquivo.name) && (!arquivo.type || arquivo.type === 'application/pdf');
            if (!ehPdf) erros.push('O arquivo precisa ser um PDF.');
            if (arquivo.size === 0) erros.push('O arquivo está vazio.');
            if (arquivo.size > TAMANHO_MAXIMO) erros.push('O arquivo passa de 20 MB.');
            if (ehPdf && jaImportado(arquivo)) erros.push('Este arquivo já foi importado (veja a lista abaixo).');
        }
        const concurso = document.getElementById('i-concurso').value.trim();
        marcar('i-concurso', concurso ? '' : 'Informe o concurso.');
        if (!concurso) erros.push('Informe o nome do concurso.');

        const anoOk = regras.anoValido(document.getElementById('i-ano').value);
        marcar('i-ano', anoOk ? '' : 'Ano inválido.');
        if (!anoOk) erros.push('O ano deve estar entre 1950 e ' + (new Date().getFullYear() + 1) + '.');

        caixaErros.hidden = erros.length === 0;
        caixaErros.innerHTML = erros.length
            ? '<strong>Não foi possível continuar:</strong><ul>' + erros.map(function (e) { return '<li>' + ui.escapar(e) + '</li>'; }).join('') + '</ul>'
            : '';
        return erros.length === 0;
    }

    // ---------- Extração simulada ----------

    function passo(n) {
        [1, 2, 3].forEach(function (i) {
            const li = document.getElementById('passo-' + i);
            li.className = i < n ? 'feito' : i === n ? 'ativo' : '';
            if (i === n) li.setAttribute('aria-current', 'step'); else li.removeAttribute('aria-current');
        });
        form.hidden = n !== 1;
        document.getElementById('revisao').hidden = n !== 2;
        document.getElementById('concluido').hidden = n !== 3;
    }

    function simularExtracao() {
        const disciplina = dados.disciplinas[Math.floor(Math.random() * dados.disciplinas.length)];
        const base = arquivo.name.replace(/\.pdf$/i, '');
        const lista = [1, 2, 3, 4].map(function (n) {
            return {
                numero: n, disciplina: disciplina,
                enunciado: 'Questão ' + n + ' extraída de "' + base + '".',
                alternativas: ['A', 'B', 'C', 'D', 'E'].map(function (l, i) {
                    return { letra: l, texto: 'Alternativa ' + l + ' da questão ' + n, correta: i === n % 5 };
                }),
                confianca: n === 3 ? 0.62 : 0.97,
                incluir: true
            };
        });
        // Uma das questões repete conteúdo já existente, para mostrar a detecção de duplicidade
        const existente = repo.questoes()[0];
        lista.push({
            numero: 5, disciplina: existente.disciplina, enunciado: existente.enunciado,
            alternativas: existente.alternativas.map(function (a) { return Object.assign({}, a); }),
            confianca: 0.95, incluir: false
        });
        lista.forEach(function (q) {
            q.duplicada = repo.duplicada(q);
            q.erros = regras.validarQuestao(q);
            if (q.duplicada) q.incluir = false;
        });
        return lista;
    }

    function desenharRevisao() {
        const repetidas = extraidas.filter(function (q) { return q.duplicada; }).length;
        document.getElementById('resumo-revisao').textContent = plural(extraidas.length, 'questão encontrada', 'questões encontradas')
            + (repetidas === 0 ? '.'
                : '; ' + (repetidas === 1 ? '1 já existe no banco e foi desmarcada.' : repetidas + ' já existem no banco e foram desmarcadas.'));
        document.getElementById('lista-revisao').innerHTML = extraidas.map(function (q, i) {
            const avisos = [];
            if (q.duplicada) avisos.push('<span class="badge badge-warn">Já existe</span>');
            if (q.confianca < 0.8) avisos.push('<span class="badge badge-warn">Confira o texto</span>');
            if (q.erros.length) avisos.push('<span class="badge badge-error">' + ui.escapar(q.erros[0]) + '</span>');
            return '<div class="revisao-item">'
                + '<input type="checkbox" data-i="' + i + '" aria-label="Incluir questão ' + q.numero + '"'
                + (q.incluir ? ' checked' : '') + (q.duplicada ? ' disabled' : '') + '>'
                + '<div><strong>Questão ' + q.numero + '</strong> · ' + ui.escapar(q.disciplina) + '<br>'
                + '<span class="muted">' + ui.escapar(q.enunciado) + '</span></div>'
                + '<div class="acoes">' + avisos.join('') + '</div></div>';
        }).join('');
    }

    form.addEventListener('submit', function (e) {
        e.preventDefault();
        if (!validar()) { caixaErros.scrollIntoView({ block: 'nearest' }); return; }

        const botao = document.getElementById('enviar');
        const ocr = document.getElementById('i-ocr').checked;
        const barra = document.getElementById('progresso-barra');
        botao.disabled = true;
        document.getElementById('progresso').hidden = false;
        let pct = 0;
        const timer = setInterval(function () {
            pct = Math.min(100, pct + (ocr ? 7 : 14));
            barra.style.width = pct + '%';
            document.getElementById('progresso-pct').textContent = pct + '%';
            document.getElementById('progresso-texto').textContent = pct < 100
                ? (ocr ? 'Reconhecendo texto (OCR)…' : 'Lendo páginas…') : 'Pronto';
            if (pct >= 100) {
                clearInterval(timer);
                botao.disabled = false;
                extraidas = simularExtracao();
                desenharRevisao();
                passo(2);
            }
        }, 120);
    });

    document.getElementById('lista-revisao').addEventListener('change', function (e) {
        const i = e.target.dataset.i;
        if (i != null) extraidas[i].incluir = e.target.checked;
    });

    document.getElementById('todas').addEventListener('change', function (e) {
        extraidas.forEach(function (q) { if (!q.duplicada) q.incluir = e.target.checked; });
        desenharRevisao();
    });

    document.getElementById('voltar').addEventListener('click', function () { passo(1); });

    document.getElementById('confirmar').addEventListener('click', function () {
        const selecionadas = extraidas.filter(function (q) { return q.incluir && !q.duplicada && q.erros.length === 0; });
        if (selecionadas.length === 0) {
            ui.aviso('Selecione ao menos uma questão válida.');
            return;
        }
        const concurso = document.getElementById('i-concurso').value.trim();
        const banca = document.getElementById('i-banca').value.trim();
        const ano = document.getElementById('i-ano').value ? Number(document.getElementById('i-ano').value) : null;
        selecionadas.forEach(function (q) {
            repo.adicionarQuestao({
                numero: q.numero, disciplina: q.disciplina, enunciado: q.enunciado, alternativas: q.alternativas,
                concurso: concurso, banca: banca, ano: ano, anulada: false
            });
        });
        repo.registrarImportacao({
            arquivo: arquivo.name, tamanho: arquivo.size, concurso: concurso, banca: banca, ano: ano,
            em: new Date().toISOString(), questoes: selecionadas.length
        });
        const ignoradas = extraidas.length - selecionadas.length;
        document.getElementById('resumo-final').textContent = plural(selecionadas.length, 'questão salva', 'questões salvas')
            + (ignoradas ? ', ' + plural(ignoradas, 'ignorada (repetida ou desmarcada).', 'ignoradas (repetidas ou desmarcadas).') : '.');
        passo(3);
        desenharImportacoes();
    });

    document.getElementById('nova').addEventListener('click', function () {
        form.reset();
        escolher(null);
        document.getElementById('progresso').hidden = true;
        document.getElementById('progresso-barra').style.width = '0%';
        caixaErros.hidden = true;
        passo(1);
    });

    function desenharImportacoes() {
        const lista = repo.importacoes();
        const corpo = document.getElementById('t-importacoes');
        if (lista.length === 0) {
            corpo.innerHTML = '<tr><td colspan="4" class="empty">Nenhuma importação ainda.</td></tr>';
            return;
        }
        corpo.innerHTML = lista.map(function (i) {
            return '<tr><td>' + ui.escapar(i.arquivo) + '</td>'
                + '<td>' + ui.escapar(regras.rotuloConcurso(i.banca, i.ano, i.concurso)) + '</td>'
                + '<td>' + ui.dataHora(i.em) + '</td>'
                + '<td class="num">' + i.questoes + '</td></tr>';
        }).join('');
    }

    desenharImportacoes();
});
