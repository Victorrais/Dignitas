# Dignitas Web — front-end (Etapa 8)

Páginas do sistema web do Dignitas em HTML, CSS e JavaScript puro, sem back-end.
Os dados ficam no `localStorage` do navegador; as regras de validação espelham as do núcleo Java
(`QuestionDraft.validate`, `Texts.normalize`, `ExamLabels.of`).

## Como abrir

Abra `index.html` direto no navegador, ou sirva a pasta:

```bash
python -m http.server 5500 --directory web
```

Depois acesse http://localhost:5500.

## Estrutura

| Pasta / arquivo | Conteúdo |
|---|---|
| `index.html` | Painel: indicadores, últimas respostas, acerto por disciplina |
| `questoes.html` | Lista com busca, filtros, ordenação, paginação e marcação para revisão |
| `editor.html` | Cadastro de questão com alternativas dinâmicas e validação |
| `praticar.html` | Resolver questões com gabarito imediato e atalhos de teclado |
| `historico.html` | Respostas registradas, com filtros |
| `estatisticas.html` | Totais, gráfico dos últimos 7 dias, acerto por disciplina e banca |
| `importar.html` | Envio de PDF em 3 etapas (arquivo, revisão, concluído) |
| `css/base.css` | Cores (tema claro e escuro), tipografia e componentes |
| `css/layout.css` | Menu lateral, cabeçalho, grades e responsividade |
| `css/paginas.css` | Estilos específicos de cada página |
| `js/dados.js` | Questões de exemplo |
| `js/regras.js` | Regras de negócio (validação, normalização, percentual, paginação) |
| `js/armazenamento.js` | Leitura e gravação no `localStorage` |
| `js/app.js` | Menu mobile, tema, avisos e utilitários comuns |
| `js/<página>.js` | Comportamento de cada página |
| `wireframes/` | Wireframes de baixa fidelidade (HTML) e `wireframes/png/` |
| `prototipos/` | Capturas dos protótipos: desktop, mobile e tema escuro |

## Validações com JavaScript

- **Nova questão:** enunciado obrigatório; 2 a 5 alternativas, nenhuma vazia; exatamente uma correta
  (exceto questão anulada); ano entre 1950 e o ano seguinte; número da questão inteiro positivo;
  bloqueio de questão repetida (comparação sem acentos, maiúsculas e pontuação).
- **Importar PDF:** arquivo obrigatório; somente `.pdf`; não vazio; até 20 MB; não importado antes;
  concurso obrigatório; ano válido.
- **Questões:** busca exige pelo menos 3 caracteres.
- **Praticar:** exige escolher uma alternativa antes de responder.
- **Histórico:** confirmação antes de apagar.

## Funcionalidades dinâmicas

Filtros em tempo real, paginação, alternativas adicionadas e removidas com reordenação das letras,
alternância entre múltipla escolha e certo/errado, contador de caracteres, gabarito destacado,
atalhos de teclado (A–E, Enter, N), arrastar e soltar o PDF, barra de progresso, gráfico de barras,
menu lateral recolhível no celular e tema claro/escuro lembrado entre visitas.
