/* Histórico: lista as respostas com filtro por texto e por resultado. */
document.addEventListener('DOMContentLoaded', function () {
    const { repo, regras, ui } = Dignitas;
    const corpo = document.getElementById('tabela');
    const texto = document.getElementById('h-texto');
    const resultado = document.getElementById('h-resultado');

    function desenhar() {
        const busca = regras.normalizar(texto.value);
        const filtro = resultado.value;
        const linhas = repo.tentativas().slice().reverse().filter(function (t) {
            if (filtro === 'certas' && !t.correta) return false;
            if (filtro === 'erradas' && t.correta) return false;
            if (busca) {
                const q = repo.questao(t.questaoId);
                if (!q || regras.normalizar(q.enunciado).indexOf(busca) < 0) return false;
            }
            return true;
        });

        document.getElementById('contagem').textContent = linhas.length + (linhas.length === 1 ? ' resposta' : ' respostas');
        if (linhas.length === 0) {
            corpo.innerHTML = '<tr><td colspan="5" class="empty">Nenhuma resposta encontrada. '
                + '<a href="praticar.html">Praticar agora</a>.</td></tr>';
            return;
        }
        corpo.innerHTML = linhas.map(function (t) {
            const q = repo.questao(t.questaoId);
            return '<tr>'
                + '<td>' + ui.dataHora(t.em) + '</td>'
                + '<td><a class="enunciado-curto" href="praticar.html?id=' + t.questaoId + '">'
                + ui.escapar(q ? q.enunciado : 'Questão removida') + '</a></td>'
                + '<td>' + ui.escapar(q ? regras.rotuloConcurso(q.banca, q.ano, q.concurso) : '—') + '</td>'
                + '<td>' + ui.escapar(t.letra) + '</td>'
                + '<td><span class="badge ' + (t.correta ? 'badge-ok">Certa' : 'badge-error">Errada') + '</span></td>'
                + '</tr>';
        }).join('');
    }

    document.getElementById('form-filtros').addEventListener('input', desenhar);
    document.getElementById('form-filtros').addEventListener('submit', function (e) { e.preventDefault(); });

    document.getElementById('limpar').addEventListener('click', function () {
        const total = repo.tentativas().length;
        if (total === 0) { ui.aviso('O histórico já está vazio.'); return; }
        if (!confirm('Apagar as ' + total + ' respostas do histórico? Esta ação não pode ser desfeita.')) return;
        repo.limparTentativas();
        ui.aviso('Histórico apagado.');
        desenhar();
    });

    desenhar();
});
